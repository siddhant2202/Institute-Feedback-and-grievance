<?php
$conn=mysqli_connect("localhost","root","","fs")or die(mysqli_error());
?>